import warnings
warnings.filterwarnings("ignore", category=UserWarning, module='google.protobuf')

import cv2
import mediapipe as mp
import numpy as np
import os
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import LSTM, Dense, Dropout
from tensorflow.keras.utils import to_categorical
from tensorflow.keras.models import load_model
import argparse

# Initialize MediaPipe hands solution
mp_hands = mp.solutions.hands
mp_drawing = mp.solutions.drawing_utils
hands = mp_hands.Hands(max_num_hands=1)

DATA_PATH = 'gesture_data'  # Path to save the collected data
sequence_length = 30        # Sequence length for the LSTM model
actions = ['V','1','A', '3']   # Define gestures/signs (customize as needed)

def extract_keypoints(hand_landmarks):
    return [[lm.x, lm.y, lm.z] for lm in hand_landmarks.landmark]

def collect_data():
    cap = cv2.VideoCapture(0)
    
    while True:
        # Prompt user to enter the action to collect
        action = input("Enter the gesture action to collect (e.g., 'A', 'B', 'C') or type 'exit' to stop: ").upper()
        
        if action == 'EXIT':
            break
        
        if action not in actions:
            print("Invalid action. Please enter a valid action or 'exit' to stop.")
            continue
        
        action_dir = os.path.join(DATA_PATH, action)
        os.makedirs(action_dir, exist_ok=True)
        print(f"Next batch starting: Collecting data for action '{action}'")  # Notify the start of the next batch

        for sequence in range(30):  # Collect 30 sequences per action
            frame_sequence = []
            print(f"Collecting sequence {sequence+1}/30 for action '{action}'. Press 'q' to stop early.")
            
            for frame_num in range(sequence_length):
                ret, frame = cap.read()
                if not ret:
                    print("Failed to grab frame. Exiting...")
                    cap.release()
                    cv2.destroyAllWindows()
                    return
                
                frame_rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
                result = hands.process(frame_rgb)

                if result.multi_hand_landmarks:
                    for hand_landmarks in result.multi_hand_landmarks:
                        mp_drawing.draw_landmarks(frame, hand_landmarks, mp_hands.HAND_CONNECTIONS)
                        keypoints = extract_keypoints(hand_landmarks)
                        frame_sequence.append(keypoints)
                
                cv2.imshow('Collecting Data', frame)
                if cv2.waitKey(10) & 0xFF == ord('q'):
                    print("Data collection stopped by user.")
                    break

            # Ensure sequence length is consistent by padding with zeros if necessary
            while len(frame_sequence) < sequence_length:
                frame_sequence.append(np.zeros((21, 3)))  # Pad with zeros (21 keypoints * 3 dimensions)

            np.save(os.path.join(action_dir, f'seq_{sequence}.npy'), frame_sequence)
        
        print(f"Completed collecting data for action: {action}.")
    
    cap.release()
    cv2.destroyAllWindows()

def train_model():
    sequences, labels = [], []
    label_map = {label: num for num, label in enumerate(actions)}

    for action in actions:
        for sequence_file in os.listdir(os.path.join(DATA_PATH, action)):
            sequence = np.load(os.path.join(DATA_PATH, action, sequence_file))
            sequences.append(sequence)
            labels.append(label_map[action])

    # Convert to numpy arrays
    X = np.array(sequences)
    
    # Reshape the data from (num_sequences, 30, 21, 3) to (num_sequences, 30, 63)
    X = X.reshape((X.shape[0], X.shape[1], 63))
    
    y = to_categorical(labels).astype(int)

    model = Sequential()
    model.add(LSTM(64, return_sequences=True, activation='relu', input_shape=(sequence_length, 63)))  # 63 is the flattened feature size
    model.add(LSTM(128, return_sequences=False, activation='relu'))
    model.add(Dropout(0.5))
    model.add(Dense(64, activation='relu'))
    model.add(Dense(len(actions), activation='softmax'))

    model.compile(optimizer='adam', loss='categorical_crossentropy', metrics=['accuracy'])
    model.fit(X, y, epochs=100, batch_size=32, validation_split=0.2)

    model.save('action.h5')
    print("Model trained and saved as 'action.h5'")

def real_time_recognition():
    cap = cv2.VideoCapture(0)
    model = load_model('action.h5')  # Load the trained model
    sequence = []
    threshold = 0.8

    while cap.isOpened():
        ret, frame = cap.read()
        frame_rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
        result = hands.process(frame_rgb)

        if result.multi_hand_landmarks:
            for hand_landmarks in result.multi_hand_landmarks:
                keypoints = extract_keypoints(hand_landmarks)
                sequence.append(keypoints)

                if len(sequence) == sequence_length:
                    sequence_np = np.array(sequence).reshape(1, sequence_length, 21 * 3)
                    prediction = model.predict(sequence_np)[0]
                    predicted_class = np.argmax(prediction)

                    if prediction[predicted_class] > threshold:
                        cv2.putText(frame, actions[predicted_class], (50, 50), 
                                    cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 255, 0), 2)

                    sequence.pop(0)

        cv2.imshow('Real-Time Gesture Recognition', frame)

        if cv2.waitKey(10) & 0xFF == ord('q'):
            break

    cap.release()
    cv2.destroyAllWindows()

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument('--collect', action='store_true', help="Collect new gesture data")
    parser.add_argument('--train', action='store_true', help="Train LSTM model on collected data")
    parser.add_argument('--recognize', action='store_true', help="Run real-time gesture recognition")
    args = parser.parse_args()

    if args.collect:
        collect_data()
    elif args.train:
        train_model()
    elif args.recognize:
        real_time_recognition()
    else:
        print("Please specify an action: --collect, --train, or --recognize")
